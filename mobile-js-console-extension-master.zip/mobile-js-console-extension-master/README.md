mobile-js-console-extension
===========================

Mobile JS console extension
